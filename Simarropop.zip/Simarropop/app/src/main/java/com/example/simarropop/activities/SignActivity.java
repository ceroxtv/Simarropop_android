package com.example.simarropop.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.simarropop.R;
import com.example.simarropop.conexiones.Api;
import com.example.simarropop.conexiones.RetrofitCreator;
import com.example.simarropop.pojos.Usuario;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class SignActivity extends AppCompatActivity {
    private EditText email,contrasenya, contrasenya_rep,name;
    private Button btn;

    private boolean mail,nombre,contra;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        email = findViewById(R.id.et_email);
        name = findViewById(R.id.et_usuario_crear);
        contrasenya = findViewById(R.id.et_password_crear);
        contrasenya_rep = findViewById(R.id.et_password_repetir);
        btn = findViewById(R.id.btn_entrar);

        Retrofit retrofit = RetrofitCreator.getConnection();
        Api api = retrofit.create(Api.class);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contra = contrasenya.getText().toString().equals(contrasenya_rep.getText().toString());

                Call<Usuario> callEmail = api.getEmailUsuario(email.getText().toString());
                callEmail.enqueue(new Callback<Usuario>() {
                    @Override
                    public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                        mail = false;
                        System.out.println("El email ya existe");
                    }

                    @Override
                    public void onFailure(Call<Usuario> call, Throwable t) {
                        mail = true;
                    }
                });

                Call<Usuario> callName = api.getNombreUsuario(name.getText().toString());
                callName.enqueue(new Callback<Usuario>() {
                    @Override
                    public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                        nombre = false;
                        System.out.println("El nombre ya existe");
                    }

                    @Override
                    public void onFailure(Call<Usuario> call, Throwable t) {
                        nombre = true;
                    }
                });

                if(contra && mail && nombre) {
                    Usuario u = new Usuario(name.getText().toString(),contrasenya.getText().toString(),email.getText().toString());
                    Call<Void> callInsertar = api.insertarUsuario(u);
                    callInsertar.enqueue(new Callback<Void>() {
                        @Override
                        public void onResponse(Call<Void> call, Response<Void> response) {
                            System.out.println("Insertado correctemente");
                        }

                        @Override
                        public void onFailure(Call<Void> call, Throwable t) {
                            System.out.println("Insertado no correctamente");
                        }
                    });
                }
            }
        });


    }
}