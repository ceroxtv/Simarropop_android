package com.example.simarropop.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.simarropop.R;
import com.example.simarropop.activities.ArticuloActivity;
import com.example.simarropop.activities.MainActivity;
import com.example.simarropop.conexiones.Api;
import com.example.simarropop.conexiones.RetrofitCreator;
import com.example.simarropop.pojos.Articulo;
import com.example.simarropop.pojos.Categoria;

import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class CategoriasAdapter extends RecyclerView.Adapter<CategoriasAdapter.ViewHolderDatos> implements View.OnClickListener{


    ArrayList<Categoria> listaCategorias;

    // Propiedad para el onClick
    private View.OnClickListener listener;

    // Este es nuestro constructor (puede variar según lo que queremos mostrar)
    public CategoriasAdapter(ArrayList<Categoria> listaCategorias) {
        this.listaCategorias = listaCategorias;
    }

    // El layout manager invoca este método
    // para renderizar cada elemento del RecyclerView
    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // Creamos una nueva vista
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.categoria_item, null, false);

        // Para que cada ítem ocupe el match_parent
        RecyclerView.LayoutParams lp =
                new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(lp);
        view.setOnClickListener(this);

        // Para realizar onClick

        return new ViewHolderDatos(view);
    }

    // Este método asigna valores para cada elemento de la lista
    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos holder, int position) {
        // - obtenemos un elemento del dataset según su posición
        // - reemplazamos el contenido usando tales datos
        holder.asignarDatos(listaCategorias.get(position));

    }

    // Método que define la cantidad de elementos del RecyclerView
    // Puede ser más complejo (por ejem, si implementamos filtros o búsquedas)
    @Override
    public int getItemCount() {
        return listaCategorias.size();
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View view) {
        if(listener!=null){
            listener.onClick(view);
        }
    }

    // Para realizar onClick


    // Para realizar onClick


    // Obtener referencias de los componentes visuales para cada elemento
    // Es decir, referencias de los EditText, TextViews, Buttons
    public class ViewHolderDatos extends RecyclerView.ViewHolder {

        // en este ejemplo cada elemento consta solo de un título y subtítulo
        TextView titulo;
        ImageView img_prod1;

        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            img_prod1= itemView.findViewById(R.id.img_seccion);
            titulo = itemView.findViewById(R.id.txtArticuloNombre);

            /*itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    System.out.println("Pulsaste una categoria");
                    Intent intent = new Intent(view.getContext(), MainActivity.class);
                    intent.putExtra("categoria",titulo.toString());
                    view.getContext().startActivity(intent);
                }
            });*/

        }

        public void asignarDatos(Categoria categoria) {
            img_prod1.setImageResource(R.drawable.fordfiesta);
            titulo.setText(categoria.getName());


        }
    }

    public void setList(ArrayList<Categoria> categorias){
        listaCategorias = categorias;
    }
}

