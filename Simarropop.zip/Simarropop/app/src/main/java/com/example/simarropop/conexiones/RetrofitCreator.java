package com.example.simarropop.conexiones;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitCreator {
    public static Retrofit getConnection(){
        return new Retrofit.Builder()
                .baseUrl("http://192.168.8.25:8080/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

    }
}
