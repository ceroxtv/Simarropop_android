package com.example.simarropop.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.simarropop.R;
import com.example.simarropop.conexiones.Api;
import com.example.simarropop.conexiones.RetrofitCreator;
import com.example.simarropop.pojos.Usuario;

import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class LoginActivity extends AppCompatActivity implements  View.OnClickListener {
    private TextView txtNuevo;
    private EditText usuario,contra;
    private Button btnEntrar;


    private RecyclerView recyclerGames;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtNuevo = findViewById(R.id.txtNuevoUsuario);
        usuario = findViewById(R.id.et_usuario);
        contra = findViewById(R.id.et_password);
        btnEntrar = findViewById(R.id.btn_entrar);

        txtNuevo.setOnClickListener(this);
        btnEntrar.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_entrar:
                Retrofit retrofit = RetrofitCreator.getConnection();
                Api api = retrofit.create(Api.class);

                Call<Usuario> call = api.logUsuario(usuario.getText().toString(),contra.getText().toString());
                call.enqueue(new Callback<Usuario>() {
                    @Override
                    public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                        if(response.code()== HttpsURLConnection.HTTP_OK) {
                            System.out.println("conexion ok");
                            if (response.body()!=null){
                                System.out.println("usuario detectado");
                                Usuario usuario = response.body();
                                Intent a = new Intent(LoginActivity.this,AnimationActivity.class);
                                a.putExtra("usuario",usuario);
                                startActivity(a);
                            }else {
                                Toast.makeText(LoginActivity.this,"El usuario o la contraseña son incorrectos", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }

                    @Override
                    public void onFailure(Call<Usuario> call, Throwable t) {
                        System.out.println("Error: F BRO");
                    }
                });
                break;

            case R.id.txtNuevoUsuario:
                Intent i = new Intent(LoginActivity.this,SignActivity.class);
                startActivity(i);
                break;
        }
    }
}