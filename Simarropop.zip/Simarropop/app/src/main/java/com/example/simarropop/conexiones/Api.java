package com.example.simarropop.conexiones;

import com.example.simarropop.pojos.Articulo;
import com.example.simarropop.pojos.Categoria;
import com.example.simarropop.pojos.Usuario;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.PATCH;
import retrofit2.http.Path;

public interface Api {
    @GET("usuaris")
    Call<ArrayList<Usuario>> getUsersList();

    @GET("usuaris/{id}")
    Call<Usuario> getUsuario(@Path("id")long id);

    @GET("usuaris/log/{nombre}/{contrasenya}")
    Call<Usuario> logUsuario(@Path("nombre")String nombre,@Path("contrasenya")String contrasenya);

    @GET("catego")
    Call<ArrayList<Categoria>> getCategorias();

    @GET("articuls")
    Call<ArrayList<Articulo>> getArticulos();
}
