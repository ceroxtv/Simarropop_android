package com.example.simarropop.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.simarropop.R;

public class ArticuloPublicadoActivity extends AppCompatActivity {
    private TextView textViewDescripcionAgregada, textViewPrecioAgregado;
    private Button botonSubirImagen;
    private Spinner spinnerCategoria;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_articulo_publicado);

        botonSubirImagen = findViewById(R.id.button);
        spinnerCategoria = findViewById(R.id.spinnerCategoria);

        //Ejemplo spinner
        /*
            String[] opcionesCategorias = {"Categoria 1", "Categoria 2", "Categoria 3"};
            ArrayAdapter<String> adaptador = new ArrayAdapter<>(this, android.R.layout.spinnerCategoria, opcionesCategorias);
            spinner.setAdapter(adaptador);
         */
    }
}