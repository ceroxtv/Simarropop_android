package com.example.simarropop.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.example.simarropop.R;
import com.example.simarropop.fragments.menuLateral.HomeFragment;
import com.example.simarropop.pojos.Articulo;
import com.example.simarropop.pojos.Usuario;

public class AnimationActivity extends AppCompatActivity {
    TextView txt;
    Usuario usuario;
    LottieAnimationView anime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation);

        txt = findViewById(R.id.tvAnimation);
        anime = findViewById(R.id.animacion);
        usuario = (Usuario)getIntent().getSerializableExtra("usuario");

        txt.animate().translationX(2000).setDuration(1000).setStartDelay(1200);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Bundle bundle = new Bundle();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                i.putExtra("usuario",usuario);
                startActivity(i);
            }
        },2500);
    }
}