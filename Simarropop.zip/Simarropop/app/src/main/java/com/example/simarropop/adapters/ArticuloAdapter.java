package com.example.simarropop.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.simarropop.R;
import com.example.simarropop.activities.ArticuloActivity;
import com.example.simarropop.pojos.Articulo;

import java.util.ArrayList;

public class ArticuloAdapter extends RecyclerView.Adapter<ArticuloAdapter.ViewHolderDatos>{


    ArrayList<Articulo> listaArticulos;
// LISTA para filtrar busqueda search
    ArrayList<Articulo> listaOriginal;

    private View.OnClickListener listener;

    public ArticuloAdapter(ArrayList<Articulo> listaArticulos) {
        this.listaArticulos = listaArticulos;

        // searchView (para buscar articulos)
            listaOriginal = new ArrayList<>();
            listaOriginal.addAll(listaArticulos);
    }

    // El layout manager invoca este método
    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // Creamos una nueva vista
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.articulo_item, null, false);

        // Para que cada ítem ocupe el match_parent
        RecyclerView.LayoutParams lp =
                new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(lp);
        return new ViewHolderDatos(view);
    }

    // Este método asigna valores para cada elemento de la lista
    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos holder, int position) {
        // - obtenemos un elemento del dataset según su posición
        // - reemplazamos el contenido usando tales datos
        holder.asignarDatos(listaArticulos.get(position));

    }

// METODO FILTRADO SEARCH, Busqueda por nombre
    public void filtrado(String cadenaTxt_a_buscar){
        int longitudCadena =  cadenaTxt_a_buscar.length();

        //
            if (longitudCadena == 0){
                listaArticulos.clear(); // limpiar
                listaArticulos.addAll(listaOriginal); // si no tenemos info, que regrese los datos que ya tenemos
            }else{
                listaArticulos.clear(); // limpiar
                for (Articulo articulo : listaOriginal ) {
                        if (articulo.getName().toLowerCase().contains(cadenaTxt_a_buscar.toLowerCase())) {
                            listaArticulos.add(articulo);
                        }
                }
            }
            notifyDataSetChanged();
    }

    // Método que define la cantidad de elementos del RecyclerView
    // Puede ser más complejo (por ejem, si implementamos filtros o búsquedas)
    @Override
    public int getItemCount() {
        return listaArticulos.size();
    }


    // Para realizar onClick
    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    // Obtener referencias de los componentes visuales para cada elemento
    // Es decir, referencias de los EditText, TextViews, Buttons
    public class ViewHolderDatos extends RecyclerView.ViewHolder {

        // en este ejemplo cada elemento consta solo de un título y subtítulo
        TextView titulo1, precio1;
        ImageView img_prod1;



        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            img_prod1= itemView.findViewById(R.id.img_seccion);
            precio1 = itemView.findViewById(R.id.txtArticuloPrecio);
            titulo1 = itemView.findViewById(R.id.txtArticuloNombre);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(view.getContext(), ArticuloActivity.class);
                    intent.putExtra("articulo",listaArticulos.get(getAbsoluteAdapterPosition()));
                    view.getContext().startActivity(intent);
                }
            });
        }

        public void asignarDatos(Articulo producto) {
            img_prod1.setImageResource(R.drawable.fordfiesta);

            precio1.setText(String.valueOf(producto.getPrecio()));
            titulo1.setText(producto.getName());
        }


    }

    public Articulo getArticuloAt(int posicion){
        return listaArticulos.get(posicion);
    }

    public void setList(ArrayList<Articulo> articulos) {
        listaArticulos = articulos;
    }
}

