package com.example.simarropop.pojos;

import java.io.Serializable;
import java.util.ArrayList;

public class Articulo implements Serializable {

    private long id;
    private String name;
    private Float precio;
    private String descripcion;
    private String ubicacion;
    private Categoria categoria;
    private Usuario usuario;
    private Usuario usuario_comprador;

    private ArrayList<String> fotos;

    public ArrayList<String> getFotos() {
        return fotos;
    }

    public void setFotos(ArrayList<String> fotos) {
        this.fotos = fotos;
    }

    public Articulo(long id, String name, Float precio, String descripcion, String ubicacion, Categoria categoria, Usuario usuario, Usuario usuario_comprador) {
        this.id = id;
        this.name = name;
        this.precio = precio;
        this.descripcion = descripcion;
        this.ubicacion = ubicacion;
        this.categoria = categoria;
        this.usuario = usuario;
        this.usuario_comprador = usuario_comprador;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Usuario getUsuario_comprador() {
        return usuario_comprador;
    }

    public void setUsuario_comprador(Usuario usuario_comprador) {
        this.usuario_comprador = usuario_comprador;
    }
}
