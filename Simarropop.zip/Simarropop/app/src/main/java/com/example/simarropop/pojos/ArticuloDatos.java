package com.example.simarropop.pojos;

import java.util.ArrayList;

public class ArticuloDatos {
    public static ArrayList <Articulo> ARTICULOS = new ArrayList<>();
    /*static{
        ARTICULOS.add(new Articulo("Coche","100$", "Cochesito nuevesito"));
        ARTICULOS.add(new Articulo("Moto","200$", "Motosita viejita"));
        ARTICULOS.add(new Articulo("PC","150$","PC caca"));
        ARTICULOS.add(new Articulo("Esponja","300$", "Esponja no absorbente"));
        ARTICULOS.add(new Articulo("Alcachofa","500$", "Alcachofa pasada"));
        ARTICULOS.add(new Articulo("Television","100$","Television Antigua gorda"));


    }*/
}
