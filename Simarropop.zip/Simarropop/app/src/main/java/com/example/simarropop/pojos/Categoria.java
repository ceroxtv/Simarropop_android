package com.example.simarropop.pojos;

import java.io.Serializable;

public class Categoria implements Serializable {
    private String name;
    private String descripcion_categoria;

    private String fotos;

    public String getFotos() {
        return fotos;
    }

    public void setFotos(String fotos) {
        this.fotos = fotos;
    }

    public Categoria(String titulo, String descripcion_categoria) {
        this.name = titulo;
        this.descripcion_categoria = descripcion_categoria;
    }

    public Categoria(String titulo) {
        this.name = titulo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescripcion_categoria() {
        return descripcion_categoria;
    }

    public void setDescripcion_categoria(String descripcion_categoria) {
        this.descripcion_categoria = descripcion_categoria;
    }
}
