package com.example.simarropop.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;

import com.example.simarropop.R;
import com.example.simarropop.conexiones.Api;
import com.example.simarropop.conexiones.RetrofitCreator;
import com.example.simarropop.pojos.Articulo;
import com.example.simarropop.pojos.Categoria;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ImagenActivity extends AppCompatActivity {
    private ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imagen);

        img = findViewById(R.id.imgA);

        Retrofit retrofit = RetrofitCreator.getConnection();
        Api api = retrofit.create(Api.class);

        Call<ArrayList<Articulo>> call = api.getArticulos();
        call.enqueue(new Callback<ArrayList<Articulo>>() {
            @Override
            public void onResponse(Call<ArrayList<Articulo>> call, Response<ArrayList<Articulo>> response) {
                ArrayList <Articulo> a = response.body();
                String base = a.get(0).getFotos().get(0);
                byte[] byt = Base64.decode(base,Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(byt,0,byt.length);

                img.setImageBitmap(bitmap);
            }

            @Override
            public void onFailure(Call<ArrayList<Articulo>> call, Throwable t) {

            }
        });


    }
}