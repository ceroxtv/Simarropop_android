package com.example.simarropop.fragments.menuLateral;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.simarropop.R;

public class ProfileFragment extends Fragment {
private Button botonPerfilCompras, botonPerfilVentas, botonPerfilArticulosFav;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

            botonPerfilCompras = view.findViewById(R.id.botonPerfilCompras);
            botonPerfilVentas = view.findViewById(R.id.botonPerfilVentas);
            botonPerfilArticulosFav = view.findViewById(R.id.botonPerfilArticulosFav);

            botonPerfilCompras.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            botonPerfilVentas.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });

            botonPerfilArticulosFav.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });


        return inflater.inflate(R.layout.fragment_profile, container, false);
    }
}