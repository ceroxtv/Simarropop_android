package com.example.simarropop.fragments.menuLateral;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.simarropop.R;
import com.example.simarropop.pojos.Usuario;

public class ProfileFragment extends Fragment {
private Button botonPerfilCompras, botonPerfilVentas, botonPerfilArticulosFav;

private ImageView img;
private TextView nombre;
private Usuario usuario;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        botonPerfilCompras = view.findViewById(R.id.botonPerfilCompras);
        botonPerfilVentas = view.findViewById(R.id.botonPerfilVentas);
        botonPerfilArticulosFav = view.findViewById(R.id.botonPerfilArticulosFav);
        nombre = view.findViewById(R.id.tvNombrePerfil);
        img  = view.findViewById(R.id.imagenPerfil);

        Bundle bundle = getArguments();
        usuario = (Usuario)bundle.getSerializable("usuario");
        nombre.setText(usuario.getName());

        String base = usuario.getFotos();
        byte[] byt = Base64.decode(base,Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(byt,0,byt.length);
        img.setImageBitmap(bitmap);

            botonPerfilCompras.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            botonPerfilVentas.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });

            botonPerfilArticulosFav.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                });


        return view;
    }
}