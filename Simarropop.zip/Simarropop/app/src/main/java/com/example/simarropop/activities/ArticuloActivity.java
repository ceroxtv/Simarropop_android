package com.example.simarropop.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import com.example.simarropop.R;
import com.example.simarropop.pojos.Articulo;

public class ArticuloActivity extends AppCompatActivity {
    private TextView txtNombreArticuloUnico, txtPrecio, txtDescripcion;
    private Articulo articulo;
    private boolean favorite = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_articulo);

        txtNombreArticuloUnico = findViewById(R.id.txtNombreArticuloUnico);
        txtPrecio = findViewById(R.id.txtPrecio);
        txtDescripcion = findViewById(R.id.txtDescripcion);

        articulo = (Articulo)getIntent().getSerializableExtra("articulo");


        String nombreArticulo = articulo.getName();
        Float precioArticulo = articulo.getPrecio();
        String descripcionArticulo = articulo.getDescripcion();


        txtNombreArticuloUnico.setText(nombreArticulo);
        txtPrecio.setText(String.valueOf(precioArticulo));
        txtDescripcion.setText(descripcionArticulo);


        Toolbar toolbarArticulo = findViewById(R.id.toolbarArticulo);

        toolbarArticulo.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        ImageView imgFavorite = findViewById(R.id.img_favorite);


        imgFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (favorite) {
                    imgFavorite.setBackground(getDrawable(R.drawable.ic_baseline_favorite_border_24));
                    favorite = false;
                } else {
                    imgFavorite.setBackground(getDrawable(R.drawable.ic_baseline_favorite_24));
                    favorite = true;
                }
            }
        });

    }
}