package com.example.simarropop.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.simarropop.R;
import com.example.simarropop.pojos.Articulo;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;

public class ArticuloActivity extends AppCompatActivity implements OnMapReadyCallback {
    private TextView txtNombreArticuloUnico, txtPrecio, txtDescripcion;

    private GoogleMap mMap;
    private ImageView img;
    private Articulo articulo;
    private boolean favorite = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_articulo);

        txtNombreArticuloUnico = findViewById(R.id.txtNombreArticuloUnico);
        txtPrecio = findViewById(R.id.txtPrecio);
        txtDescripcion = findViewById(R.id.txtDescripcion);
        img = findViewById(R.id.imgProducto);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapita);
        mapFragment.getMapAsync(this);

        articulo = (Articulo)getIntent().getSerializableExtra("articulo");


        String nombreArticulo = articulo.getName();
        Float precioArticulo = articulo.getPrecio();
        String descripcionArticulo = articulo.getDescripcion();


        txtNombreArticuloUnico.setText(nombreArticulo);
        txtPrecio.setText(String.valueOf(precioArticulo)+"€");
        txtDescripcion.setText(descripcionArticulo);

        String base = articulo.getFotos().get(0);
        byte[] byt = Base64.decode(base,Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(byt,0,byt.length);
        img.setImageBitmap(bitmap);


        Toolbar toolbarArticulo = findViewById(R.id.toolbarArticulo);

        toolbarArticulo.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        ImageView imgFavorite = findViewById(R.id.img_favorite);


        imgFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (favorite) {
                    imgFavorite.setBackground(getDrawable(R.drawable.ic_baseline_favorite_border_24));
                    favorite = false;
                } else {
                    imgFavorite.setBackground(getDrawable(R.drawable.ic_baseline_favorite_24));
                    favorite = true;
                }
            }
        });



    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions();
        } else {
            ubicacionActual();
        }
    }

    private void ubicacionActual() {
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;

        }else{
            mMap.setMyLocationEnabled(true);
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {
                                LatLng posActual = new LatLng(38.986449,-0.535475);
                                //LatLng posActual = new LatLng(location.getLatitude(), location.getLongitude());
                                mMap.addMarker(new MarkerOptions().position(posActual).title("Estás aquí"));
                                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(posActual,15));
                            } else {
                                Toast.makeText(ArticuloActivity.this, "No se pudo obtener la ubicación actual", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }

    }
}