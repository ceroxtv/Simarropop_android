package com.example.simarropop.fragments.menuLateral;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.simarropop.R;
import com.example.simarropop.activities.AnimationActivity;
import com.example.simarropop.activities.ArticuloActivity;
import com.example.simarropop.activities.LoginActivity;
import com.example.simarropop.activities.MainActivity;
import com.example.simarropop.adapters.ArticuloAdapter;
import com.example.simarropop.conexiones.Api;
import com.example.simarropop.conexiones.RetrofitCreator;
import com.example.simarropop.pojos.Categoria;
import com.example.simarropop.pojos.CategoriaDatos;
import com.example.simarropop.adapters.CategoriasAdapter;
import com.example.simarropop.pojos.Articulo;
import com.example.simarropop.pojos.ArticuloDatos;
import com.example.simarropop.pojos.Usuario;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.sql.SQLOutput;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class HomeFragment extends Fragment implements  SearchView.OnQueryTextListener{
    private RecyclerView recycler,recyclerHZ;
    private ArrayList<Articulo> articulos;
    private ArrayList<Categoria> categorias;
    private CategoriasAdapter categoriasAdapter;
    private ArticuloAdapter articuloAdapter;
    private SearchView searchView;

    // Botones FAB  ( un botonPadre puslado muestra otros botones )
    private ExtendedFloatingActionButton botonFabPadre;
    private FloatingActionButton botonFabAgregarArticulo, botonFabArticuloFavoritos;
    boolean isAllFabVisible; // comprobar cuando son visibles



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Search View
        searchView = view.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(this);

        // RELLENAR LAS CATEGORIAS
        categorias = new ArrayList<>();
        recyclerHZ = view.findViewById(R.id.recyclerCategorias);
        recyclerHZ.setHasFixedSize(true);
        categoriasAdapter = new CategoriasAdapter(categorias);
        recyclerHZ.setAdapter(categoriasAdapter);

        Retrofit retrofit = RetrofitCreator.getConnection();
        Api api = retrofit.create(Api.class);

        Call<ArrayList<Categoria>> call = api.getCategorias();
        call.enqueue(new Callback<ArrayList<Categoria>>() {
            @Override
            public void onResponse(Call<ArrayList<Categoria>> call, Response<ArrayList<Categoria>> response) {
                if(response.code()== HttpsURLConnection.HTTP_OK) {
                    System.out.println("conexion ok");
                    if (response.body()!=null){
                        System.out.println("categorias detectadas");
                        categorias = response.body();
                        categoriasAdapter.setList(categorias);
                        categoriasAdapter.notifyDataSetChanged();
                    }else {
                        System.out.println("ES NULL F");
                    }

                }
            }
            @Override
            public void onFailure(Call<ArrayList<Categoria>> call, Throwable t) {
                System.out.println("Error en la categoria");
            }
        });

        categoriasAdapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int posicion = recyclerHZ.getChildAdapterPosition(view);
                Call<ArrayList<Articulo>> callCat = api.getArticulosCategoria(categorias.get(posicion).getName());
                callCat.enqueue(new Callback<ArrayList<Articulo>>() {
                    @Override
                    public void onResponse(Call<ArrayList<Articulo>> call, Response<ArrayList<Articulo>> response) {
                        if (response.body()!=null){
                            System.out.println("categorias nombre detectada");
                            articulos = response.body();
                            articuloAdapter.setList(articulos);
                            articuloAdapter.notifyDataSetChanged();
                        }else {
                            System.out.println("ES NULL F");
                        }
                    }

                    @Override
                    public void onFailure(Call<ArrayList<Articulo>> call, Throwable t) {

                    }
                });
            }
        });

        //RELLENAR LOS ARTICULOS
        articulos = new ArrayList<>();
        recycler = view.findViewById(R.id.recyclerProductos);
        recycler.setHasFixedSize(true);
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(),2);
        recycler.setLayoutManager(layoutManager);
        articuloAdapter = new ArticuloAdapter(articulos);
        recycler.setAdapter(articuloAdapter);

        Call<ArrayList<Articulo>> call2 = api.getArticulos();
        call2.enqueue(new Callback<ArrayList<Articulo>>() {
            @Override
            public void onResponse(Call<ArrayList<Articulo>> call, Response<ArrayList<Articulo>> response) {
                if(response.code()== HttpsURLConnection.HTTP_OK) {
                    System.out.println("conexion ok");
                    if (response.body()!=null){
                        System.out.println("articulos detectados");
                        articulos = response.body();
                        articuloAdapter.setList(articulos);
                        articuloAdapter.notifyDataSetChanged();

                    }else {
                        System.out.println("ES NULL F");
                    }

                }
            }

            @Override
            public void onFailure(Call<ArrayList<Articulo>> call, Throwable t) {
                System.out.println("Error en los articulos");
            }
        });

        LinearLayoutManager layoutHZ = new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false);
        recyclerHZ.setLayoutManager(layoutHZ);



        // Botones FAB
            botonFabPadre = view.findViewById(R.id.botonFabPadre);
            botonFabAgregarArticulo = view.findViewById(R.id.botonFabAgregarArticulo);
            botonFabArticuloFavoritos = view.findViewById(R.id.botonFabArticuloFavoritos);
                botonFabAgregarArticulo.setVisibility(View.GONE);
                botonFabArticuloFavoritos.setVisibility(View.GONE);

            isAllFabVisible = false;
            // permite redudir el tamaño del boton flotante
                // para que sea mas pequeño y para ahorrar espacio
            botonFabPadre.shrink();
                botonFabPadre.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!isAllFabVisible) {
                            botonFabAgregarArticulo.show();
                            botonFabArticuloFavoritos.show();

                             botonFabPadre.extend();
                             isAllFabVisible = true;

                        }else {
                            botonFabAgregarArticulo.hide();
                            botonFabArticuloFavoritos.hide();

                            botonFabPadre.shrink();
                            isAllFabVisible = false;
                        }

                    }
                });


            botonFabAgregarArticulo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getActivity(), "Subir un Articulo", Toast.LENGTH_SHORT).show();
                    }
                });

            botonFabArticuloFavoritos.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getActivity(), "Articulos Favoritos", Toast.LENGTH_SHORT).show();
                }
            });

        return view;

    }


    // --------------------- SEARCH VIEW ---------------------
    // Buscar en tiempo real
    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        articuloAdapter.filtrado(newText);
        return false;
    }
}

