package com.example.simarropop.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;


import com.example.simarropop.R;
import com.example.simarropop.conexiones.Api;
import com.example.simarropop.conexiones.RetrofitCreator;
import com.example.simarropop.fragments.menuLateral.AboutFragment;
import com.example.simarropop.fragments.menuLateral.HomeFragment;
import com.example.simarropop.fragments.menuLateral.ProfileFragment;
import com.example.simarropop.fragments.menuLateral.SettingsFragment;
import com.example.simarropop.pojos.Usuario;
import com.google.android.material.navigation.NavigationView;

import javax.net.ssl.HttpsURLConnection;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
private DrawerLayout drawerLayout;
private Toolbar toolbar;
private Retrofit retrofit;
private HomeFragment fg;
private ProfileFragment pg;

private Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle bundle = new Bundle();
        usuario = (Usuario)getIntent().getSerializableExtra("usuario");
        bundle.putSerializable("usuario",usuario);

        fg = new HomeFragment();
        fg.setArguments(bundle);
    // Menu Lateral
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        pg = new ProfileFragment();
        pg.setArguments(bundle);


        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);

            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();

            if(savedInstanceState == null){
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fg).commit();
            }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_home:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fg).commit();
                break;

            case R.id.nav_profile:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, pg).commit();
                break;

            case R.id.nav_about:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new AboutFragment()).commit();
                break;

            case R.id.nav_settings:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new SettingsFragment()).commit();
                toolbar.setTitle(R.string.app_settings);
                break;

            case R.id.nav_logout:
                Toast.makeText(this,"Saliendo",Toast.LENGTH_SHORT).show();
                break;
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }


}