package com.example.simarropop.pojos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Date;

public class Usuario implements Serializable {

    private long id;

    private String name;

    private String contrasenya;

    private String email;

    private String phone;

    private String city;

    private Float valoracion_media;

    private Date fecha;


    public Usuario(long id, String name, String contrasenya, String email, String phone, String city, Float valoracion_media, Date fecha) {
        this.id = id;
        this.name = name;
        this.contrasenya = contrasenya;
        this.email = email;
        this.phone = phone;
        this.city = city;
        this.valoracion_media = valoracion_media;
        this.fecha = fecha;
    }

    public Usuario(String name, String contrasenya, String email){
        this.name = name;
        this.contrasenya = contrasenya;
        this.email = email;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Float getValoracion_media() {
        return valoracion_media;
    }

    public void setValoracion_media(Float valoracion_media) {
        this.valoracion_media = valoracion_media;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
